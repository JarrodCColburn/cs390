#ifndef LIBHELLO_H_
#define LIBHELLO_H_

void print_hello(void);

#endif /* LIBHELLO_H_ */
