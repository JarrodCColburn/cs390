/* libhello.c -- provides print_hello() function for libhello.so */
#include <stdio.h>

void print_hello(void) {
   printf("Hello, library.\n");
}
