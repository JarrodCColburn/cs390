/* usehello.c -- uses print_hello() function from libhello.so */
#include "libhello.h"

int main (void) {
   print_hello();
   return 0;
}
